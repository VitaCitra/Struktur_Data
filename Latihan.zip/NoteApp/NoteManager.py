# NoteManager.py
# Mengelola dua chain Doubly Linked List yang ter-sort:
#   1. Chain by Date  : urut kronologis (ascending created_at)
#   2. Chain by Title : urut alfabetikal (ascending title)
#
# Setiap note yang ditambahkan otomatis masuk ke KEDUA chain sekaligus.
# Multi-Linked per tag juga dikelola di sini.

from NoteNode import NoteNode
from datetime import datetime


class NoteManager:
    def __init__(self):
        # Head & tail untuk chain by Date
        self.headByDate  = None
        self.tailByDate  = None

        # Head & tail untuk chain by Title
        self.headByTitle = None
        self.tailByTitle = None

        # Multi-linked: head node per tag
        # key   = nama tag
        # value = NoteNode pertama dalam chain tag tersebut
        self.tagHeads: dict = {}

        self.total_notes = 0

    # ------------------------------------------------------------------ #
    #  INSERT                                                              #
    # ------------------------------------------------------------------ #
    def add_note(self, title: str, content: str, tags: list = None, created_at: datetime = None) -> NoteNode:
        """Buat note baru dan masukkan ke semua chain."""
        node = NoteNode(title, content, tags, created_at)
        self._insert_by_date(node)
        self._insert_by_title(node)
        for tag in node.tags:
            self._insert_by_tag(node, tag)
        self.total_notes += 1
        return node

    def _insert_by_date(self, new_node: NoteNode):
        """Insert ke chain Date (sorted ascending by created_at)."""
        # List kosong
        if self.headByDate is None:
            self.headByDate = self.tailByDate = new_node
            return

        # Lebih kecil dari head → insert depan
        if new_node.created_at <= self.headByDate.created_at:
            new_node.nextByDate        = self.headByDate
            self.headByDate.prevByDate = new_node
            self.headByDate            = new_node
            return

        # Lebih besar dari tail → insert belakang
        if new_node.created_at >= self.tailByDate.created_at:
            new_node.prevByDate        = self.tailByDate
            self.tailByDate.nextByDate = new_node
            self.tailByDate            = new_node
            return

        # Insert tengah: cari posisi
        cur = self.headByDate
        while cur is not None and cur.created_at < new_node.created_at:
            cur = cur.nextByDate

        # Sisipkan sebelum cur
        prev_node                  = cur.prevByDate
        new_node.nextByDate        = cur
        new_node.prevByDate        = prev_node
        prev_node.nextByDate       = new_node
        cur.prevByDate             = new_node

    def _insert_by_title(self, new_node: NoteNode):
        """Insert ke chain Title (sorted ascending alphabetically)."""
        if self.headByTitle is None:
            self.headByTitle = self.tailByTitle = new_node
            return

        if new_node.title.lower() <= self.headByTitle.title.lower():
            new_node.nextByTitle         = self.headByTitle
            self.headByTitle.prevByTitle = new_node
            self.headByTitle             = new_node
            return

        if new_node.title.lower() >= self.tailByTitle.title.lower():
            new_node.prevByTitle         = self.tailByTitle
            self.tailByTitle.nextByTitle = new_node
            self.tailByTitle             = new_node
            return

        cur = self.headByTitle
        while cur is not None and cur.title.lower() < new_node.title.lower():
            cur = cur.nextByTitle

        prev_node                    = cur.prevByTitle
        new_node.nextByTitle         = cur
        new_node.prevByTitle         = prev_node
        prev_node.nextByTitle        = new_node
        cur.prevByTitle              = new_node

    def _insert_by_tag(self, new_node: NoteNode, tag: str):
        """Insert node ke chain tag tertentu (singly, prepend)."""
        if tag not in self.tagHeads:
            self.tagHeads[tag] = new_node
        else:
            new_node.tagLinks[tag]  = self.tagHeads[tag]
            self.tagHeads[tag]      = new_node

    # ------------------------------------------------------------------ #
    #  VIEW                                                                #
    # ------------------------------------------------------------------ #
    def view_chronological(self, reverse: bool = False):
        """Tampilkan semua note urut tanggal. reverse=True → terbaru dulu."""
        print("\n📅 VIEW CHRONOLOGICAL" + (" (Terbaru → Terlama)" if reverse else " (Terlama → Terbaru)"))
        print("=" * 55)
        if reverse:
            cur = self.tailByDate
            while cur is not None:
                self._print_note(cur)
                cur = cur.prevByDate
        else:
            cur = self.headByDate
            while cur is not None:
                self._print_note(cur)
                cur = cur.nextByDate

    def view_alphabetical(self, reverse: bool = False):
        """Tampilkan semua note urut alfabetikal judul."""
        print("\n🔤 VIEW ALPHABETICAL" + (" (Z → A)" if reverse else " (A → Z)"))
        print("=" * 55)
        if reverse:
            cur = self.tailByTitle
            while cur is not None:
                self._print_note(cur)
                cur = cur.prevByTitle
        else:
            cur = self.headByTitle
            while cur is not None:
                self._print_note(cur)
                cur = cur.nextByTitle

    def view_by_tag(self, tag: str):
        """Tampilkan semua note yang memiliki tag tertentu."""
        print(f"\n🏷️  VIEW BY TAG: '{tag}'")
        print("=" * 55)
        if tag not in self.tagHeads:
            print(f"  (Tidak ada note dengan tag '{tag}')")
            return
        cur = self.tagHeads[tag]
        while cur is not None:
            self._print_note(cur)
            cur = cur.tagLinks.get(tag)

    # ------------------------------------------------------------------ #
    #  SEARCH                                                              #
    # ------------------------------------------------------------------ #
    def search_by_title(self, keyword: str):
        """Cari note berdasarkan keyword di judul (case-insensitive)."""
        print(f"\n🔍 SEARCH: '{keyword}'")
        print("=" * 55)
        found = False
        cur = self.headByTitle
        while cur is not None:
            if keyword.lower() in cur.title.lower():
                self._print_note(cur)
                found = True
            cur = cur.nextByTitle
        if not found:
            print("  (Tidak ditemukan)")

    # ------------------------------------------------------------------ #
    #  HELPER                                                              #
    # ------------------------------------------------------------------ #
    def _print_note(self, node: NoteNode):
        print(f"  📝 {node.title}")
        print(f"     Tanggal : {node.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"     Tags    : {node.tags}")
        print(f"     Isi     : {node.content[:60]}{'...' if len(node.content) > 60 else ''}")
        print()
