# SyncBuffer.py
# Circular Linked List sebagai buffer untuk melacak recent changes (sync status)
#
# Cara kerja:
#   - Buffer menyimpan maksimal `capacity` perubahan terakhir
#   - Ketika penuh, entri terlama otomatis ditimpa (circular overwrite)
#   - listRef menunjuk ke node TERAKHIR yang dimasukkan (sesuai materi slide 19)

from datetime import datetime


class SyncNode:
    """Node untuk circular buffer."""
    def __init__(self, note_title: str, action: str, timestamp: datetime = None):
        self.note_title = note_title
        self.action     = action                                          # 'ADD', 'EDIT', 'DELETE'
        self.timestamp  = timestamp if timestamp is not None else datetime.now()
        self.synced     = False                                           # status sync
        self.next       = None

    def __repr__(self):
        status = "✅ synced" if self.synced else "⏳ pending"
        return (f"[{self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}] "
                f"{self.action:6} | '{self.note_title}' | {status}")


class SyncBuffer:
    """
    Circular Linked List Buffer untuk melacak N perubahan terbaru.
    listRef → node terakhir dimasukkan.
    listRef.next → node pertama (terlama) dalam buffer.
    """

    def __init__(self, capacity: int = 5):
        self.capacity = capacity
        self.listRef  = None     # menunjuk ke node TERAKHIR (tail circular)
        self.size     = 0

    # ------------------------------------------------------------------ #
    #  RECORD CHANGE                                                       #
    # ------------------------------------------------------------------ #
    def record_change(self, note_title: str, action: str, timestamp: datetime = None):
        """
        Catat perubahan baru ke circular buffer.
        Jika sudah penuh, node terlama ditimpa otomatis.
        """
        new_node = SyncNode(note_title, action, timestamp)

        if self.listRef is None:
            # Buffer kosong → node menunjuk ke dirinya sendiri
            new_node.next = new_node
            self.listRef  = new_node
            self.size     = 1
        elif self.size < self.capacity:
            # Masih ada ruang → insert setelah listRef
            new_node.next      = self.listRef.next   # new → first
            self.listRef.next  = new_node             # last → new
            self.listRef       = new_node             # update tail
            self.size         += 1
        else:
            # Buffer penuh → timpa node terlama (listRef.next = first/oldest)
            oldest            = self.listRef.next    # node terlama
            new_node.next     = oldest.next          # sambung ke node setelah oldest
            self.listRef.next = new_node             # last → new (gantikan oldest)
            self.listRef      = new_node             # update tail

    # ------------------------------------------------------------------ #
    #  MARK SYNCED                                                         #
    # ------------------------------------------------------------------ #
    def mark_all_synced(self):
        """Tandai semua perubahan sebagai sudah ter-sync."""
        if self.listRef is None:
            return
        cur  = self.listRef
        done = False
        while not done:
            cur        = cur.next
            cur.synced = True
            done       = (cur is self.listRef)

    def mark_synced(self, note_title: str):
        """Tandai perubahan note tertentu sebagai ter-sync."""
        if self.listRef is None:
            return
        cur  = self.listRef
        done = False
        while not done:
            cur = cur.next
            if cur.note_title == note_title:
                cur.synced = True
            done = (cur is self.listRef)

    # ------------------------------------------------------------------ #
    #  VIEW                                                                #
    # ------------------------------------------------------------------ #
    def view_recent_changes(self):
        """Tampilkan semua perubahan dalam buffer (terlama → terbaru)."""
        print("\n🔄 SYNC BUFFER - Recent Changes")
        print(f"   Kapasitas: {self.size}/{self.capacity}")
        print("=" * 55)
        if self.listRef is None:
            print("  (Buffer kosong)")
            return

        # Traversal dari first (oldest) sampai last (newest)
        cur  = self.listRef
        done = False
        while not done:
            cur = cur.next
            print(f"  {cur}")
            done = (cur is self.listRef)

    def get_pending_count(self) -> int:
        """Hitung jumlah perubahan yang belum ter-sync."""
        if self.listRef is None:
            return 0
        count = 0
        cur   = self.listRef
        done  = False
        while not done:
            cur = cur.next
            if not cur.synced:
                count += 1
            done = (cur is self.listRef)
        return count
