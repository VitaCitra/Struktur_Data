# NoteNode.py
# Definisi struktur node untuk aplikasi note-taking
# Menggunakan konsep Multi-Linked List:
#   - nextByDate / prevByDate   : chain doubly linked, urut berdasarkan tanggal
#   - nextByTitle / prevByTitle : chain doubly linked, urut berdasarkan judul (alfabetikal)
#   - tagLinks                  : dict of next pointers per tag (multi-linked per tag)

from datetime import datetime


class NoteNode:
    def __init__(self, title: str, content: str, tags: list = None, created_at: datetime = None):
        """
        Parameter:
            title      : judul note
            content    : isi note
            tags       : list tag (misal: ['kuliah', 'penting'])
            created_at : waktu pembuatan note (default: sekarang)
        """
        self.title      = title
        self.content    = content
        self.tags       = tags if tags is not None else []
        self.created_at = created_at if created_at is not None else datetime.now()

        # --- Doubly Linked: chain by Date ---
        self.nextByDate = None
        self.prevByDate = None

        # --- Doubly Linked: chain by Title (alfabetikal) ---
        self.nextByTitle = None
        self.prevByTitle = None

        # --- Multi-Linked: satu pointer per tag ---
        # key   = nama tag (string)
        # value = NoteNode berikutnya dalam chain tag tersebut
        self.tagLinks: dict = {tag: None for tag in self.tags}

    def add_tag(self, tag: str):
        """Tambah tag baru ke note ini (jika belum ada)."""
        if tag not in self.tags:
            self.tags.append(tag)
            self.tagLinks[tag] = None

    def __repr__(self):
        return (f"NoteNode(title='{self.title}', "
                f"created_at='{self.created_at.strftime('%Y-%m-%d %H:%M:%S')}', "
                f"tags={self.tags})")
