# Main.py
# Entry point & demonstrasi lengkap struktur data Note-Taking App
#
# Struktur data yang digunakan (sesuai materi Advanced Linked Lists):
#   1. Multi-Linked List  → multiple tags per note
#   2. Doubly Linked List → chronological & alphabetical views
#   3. Circular Buffer    → sync status tracking (recent changes)

from datetime import datetime
from NoteManager import NoteManager
from SyncBuffer  import SyncBuffer


def main():
    print("=" * 55)
    print("   📓 NOTE-TAKING APP — Struktur Data Advanced Linked Lists")
    print("=" * 55)

    manager = NoteManager()
    buffer  = SyncBuffer(capacity=5)

    # ------------------------------------------------------------------ #
    #  1. TAMBAH NOTES                                                     #
    # ------------------------------------------------------------------ #
    print("\n➕ Menambahkan notes...")

    notes_data = [
        ("Belajar Python",        "Materi dasar Python: variabel, tipe data, fungsi.",
         ["kuliah", "programming"],   datetime(2025, 3, 10, 9, 0)),

        ("Algoritma Sorting",     "Bubble sort, merge sort, quick sort dan kompleksitasnya.",
         ["kuliah", "algoritma"],     datetime(2025, 3, 15, 14, 0)),

        ("Catatan Rapat",         "Pembahasan progress proyek akhir semester.",
         ["penting", "proyek"],       datetime(2025, 4, 1,  10, 0)),

        ("Linked List Review",    "Review singly, doubly, circular, dan multi-linked list.",
         ["kuliah", "algoritma"],     datetime(2025, 4, 20, 8, 30)),

        ("To-Do Minggu Ini",      "Kerjakan tugas struktur data dan belajar untuk UTS.",
         ["penting", "personal"],     datetime(2025, 5, 1,  7, 0)),

        ("Debugging Tips",        "Teknik debugging Python: print, logging, breakpoint.",
         ["programming", "tips"],     datetime(2025, 5, 5,  11, 0)),
    ]

    for title, content, tags, created_at in notes_data:
        manager.add_note(title, content, tags, created_at)
        buffer.record_change(title, "ADD", created_at)
        print(f"  ✅ Note ditambahkan: '{title}' | Tags: {tags}")

    # ------------------------------------------------------------------ #
    #  2. VIEW CHRONOLOGICAL                                               #
    # ------------------------------------------------------------------ #
    manager.view_chronological()                # terlama → terbaru
    manager.view_chronological(reverse=True)    # terbaru → terlama

    # ------------------------------------------------------------------ #
    #  3. VIEW ALPHABETICAL                                                #
    # ------------------------------------------------------------------ #
    manager.view_alphabetical()                 # A → Z
    manager.view_alphabetical(reverse=True)     # Z → A

    # ------------------------------------------------------------------ #
    #  4. VIEW BY TAG (Multi-Linked)                                       #
    # ------------------------------------------------------------------ #
    manager.view_by_tag("kuliah")
    manager.view_by_tag("penting")
    manager.view_by_tag("programming")

    # ------------------------------------------------------------------ #
    #  5. SEARCH BY TITLE                                                  #
    # ------------------------------------------------------------------ #
    manager.search_by_title("linked")
    manager.search_by_title("python")

    # ------------------------------------------------------------------ #
    #  6. SYNC BUFFER — Circular Linked List                              #
    # ------------------------------------------------------------------ #
    buffer.view_recent_changes()
    print(f"\n  ⏳ Pending sync: {buffer.get_pending_count()} perubahan")

    # Simulasi: tambah 2 perubahan baru (buffer penuh → timpa terlama)
    print("\n✏️  Simulasi edit & delete note (buffer overwrite)...")
    buffer.record_change("Belajar Python",    "EDIT",   datetime(2025, 5, 6, 9, 0))
    buffer.record_change("Catatan Rapat",     "DELETE", datetime(2025, 5, 6, 10, 0))

    buffer.view_recent_changes()

    # Simulasi sync sebagian
    print("\n🔁 Sync note 'Linked List Review'...")
    buffer.mark_synced("Linked List Review")
    buffer.view_recent_changes()
    print(f"\n  ⏳ Pending sync: {buffer.get_pending_count()} perubahan")

    # Sync semua
    print("\n🔁 Sync semua perubahan...")
    buffer.mark_all_synced()
    print(f"  ✅ Pending sync: {buffer.get_pending_count()} perubahan")

    print("\n" + "=" * 55)
    print("   ✅ Demo selesai!")
    print(f"   Total notes: {manager.total_notes}")
    print("=" * 55)


if __name__ == "__main__":
    main()
